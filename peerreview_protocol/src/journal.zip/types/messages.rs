use bincode::{Decode, Encode};

#[derive(Debug, Clone, Encode, Decode)]
pub enum PeerReviewMsg {
    Ping { nonce: u64 },
    Pong { nonce: u64 },

    // Placeholder : quand audit arrivera
    AuditPlaceholder { note: String },
}
