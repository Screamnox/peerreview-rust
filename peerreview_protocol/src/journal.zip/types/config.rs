use serde::{Deserialize, Serialize};

use super::node::NodeId;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PeerConfig {
    pub peers: Vec<PeerConfigEntry>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PeerConfigEntry {
    pub id: NodeId,
    pub address: String,      // ex "127.0.0.1:7002" (PR)
    pub public_key: String,   // base64 (32 bytes)
    pub witnesses: Vec<NodeId>,
}
