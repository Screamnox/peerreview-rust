use std::net::SocketAddr;

use crate::types::{PeerConfig, PeerInfo, PeerStatus};

fn parse_addr(s: &str) -> std::io::Result<SocketAddr> {
    s.parse::<SocketAddr>().map_err(|e| {
        std::io::Error::new(std::io::ErrorKind::InvalidInput, format!("bad addr '{s}': {e}"))
    })
}

/// Transforme la config en liste de peers exploitables côté réseau
pub fn peers_from_config(cfg: &PeerConfig) -> std::io::Result<Vec<PeerInfo>> {
    let mut out = Vec::new();
    for p in &cfg.peers {
        let addr = parse_addr(&p.address)?;
        out.push(PeerInfo {
            id: p.id,
            address: addr,
            status: PeerStatus::Unknown,
            public_key_b64: p.public_key.clone(),
        });
    }
    Ok(out)
}
