use std::fmt;

use base64::{engine::general_purpose, Engine as _};
use ed25519_dalek::{Signature, SigningKey, VerifyingKey};
use signature::{Signer, Verifier};

pub type NodeId = u32;

#[derive(Clone)]
pub struct Node {
    pub id: NodeId,
    signing_key: SigningKey,
    verifying_key: VerifyingKey,
}

impl fmt::Debug for Node {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Node")
            .field("id", &self.id)
            .field("verifying_key", &self.public_key_b64())
            .finish()
    }
}

impl Node {
    /// Génère une paire de clés Ed25519.
    /// Nécessite: ed25519-dalek avec feature "rand_core" + rand_core(getrandom) OU rand.
    pub fn generate(id: NodeId) -> Self {
        let mut csprng = rand::rngs::OsRng;
        let signing_key = SigningKey::generate(&mut csprng);
        let verifying_key = signing_key.verifying_key();

        Self {
            id,
            signing_key,
            verifying_key,
        }
    }

    /// Construit un Node à partir d'une clé privée encodée en base64 (64 bytes keypair bytes).
    pub fn from_private_key_b64(id: NodeId, b64: &str) -> Result<Self, String> {
        let bytes = general_purpose::STANDARD
            .decode(b64)
            .map_err(|e| format!("base64 decode error: {e}"))?;

        if bytes.len() != 64 {
            return Err(format!(
                "invalid key length: expected 64 bytes, got {}",
                bytes.len()
            ));
        }

        let mut arr = [0u8; 64];
        arr.copy_from_slice(&bytes);

        let signing_key = SigningKey::from_keypair_bytes(&arr)
            .map_err(|e| format!("invalid keypair bytes: {e}"))?;
        let verifying_key = signing_key.verifying_key();

        Ok(Self {
            id,
            signing_key,
            verifying_key,
        })
    }

    pub fn id(&self) -> NodeId {
        self.id
    }

    pub fn verifying_key(&self) -> VerifyingKey {
        self.verifying_key
    }

    pub fn public_key_b64(&self) -> String {
        let pk_bytes = self.verifying_key.to_bytes();
        general_purpose::STANDARD.encode(pk_bytes)
    }

    /// Retourne la clé privée (keypair bytes 64) encodée en base64.
    /// Utile pour écrire un fichier de config si besoin.
    pub fn private_key_b64(&self) -> String {
        let kp = self.signing_key.to_keypair_bytes();
        general_purpose::STANDARD.encode(kp)
    }

    pub fn sign(&self, data: &[u8]) -> [u8; 64] {
        let sig: Signature = self.signing_key.sign(data);
        sig.to_bytes()
    }

    pub fn verify(public_key: &VerifyingKey, data: &[u8], sig: &[u8; 64]) -> bool {
        let signature = Signature::from_bytes(sig);
        public_key.verify(data, &signature).is_ok()
    }
}
