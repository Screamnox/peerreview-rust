use std::collections::HashMap;
use std::net::SocketAddr;
use std::sync::Arc;

use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::{TcpListener, TcpStream};
use tokio::sync::Mutex;

use crate::types::{NodeId, PeerReviewMsg};

#[derive(Clone)]
pub struct NetworkLayer {
    // connections sortantes (par peer_id)
    out: Arc<Mutex<HashMap<NodeId, TcpStream>>>,
}

impl NetworkLayer {
    pub fn new() -> Self {
        Self {
            out: Arc::new(Mutex::new(HashMap::new())),
        }
    }

    /// Lance un listener PR (boucle accept) et appelle `on_msg(from, msg)` à chaque message reçu.
    pub async fn listen<F>(&self, bind: SocketAddr, mut on_msg: F) -> std::io::Result<()>
    where
        F: FnMut(SocketAddr, PeerReviewMsg) + Send + 'static,
    {
        let listener = TcpListener::bind(bind).await?;
        println!("[PR] listening on {}", bind);

        loop {
            let (mut sock, addr) = listener.accept().await?;
            println!("[PR] inbound connection from {}", addr);

            tokio::spawn(async move {
                loop {
                    // length-prefix u32 big-endian
                    let mut len_buf = [0u8; 4];
                    if sock.read_exact(&mut len_buf).await.is_err() {
                        break;
                    }
                    let len = u32::from_be_bytes(len_buf) as usize;

                    let mut buf = vec![0u8; len];
                    if sock.read_exact(&mut buf).await.is_err() {
                        break;
                    }

                    let decoded: Result<(PeerReviewMsg, usize), _> =
                        bincode::decode_from_slice(&buf, bincode::config::standard());

                    match decoded {
                        Ok((msg, _used)) => on_msg(addr, msg),
                        Err(e) => {
                            eprintln!("[PR] decode error from {}: {}", addr, e);
                            break;
                        }
                    }
                }
            });
        }
    }

    /// Ouvre (ou réutilise) une connexion sortante vers un peer.
    pub async fn connect(&self, peer_id: NodeId, addr: SocketAddr) -> std::io::Result<()> {
        let mut out = self.out.lock().await;
        if out.contains_key(&peer_id) {
            return Ok(());
        }
        let stream = TcpStream::connect(addr).await?;
        out.insert(peer_id, stream);
        Ok(())
    }

    /// Envoie un message PR (bincode2 + length-prefix).
    pub async fn send(&self, peer_id: NodeId, msg: &PeerReviewMsg) -> std::io::Result<()> {
        let payload =
            bincode::encode_to_vec(msg, bincode::config::standard()).map_err(|e| {
                std::io::Error::new(std::io::ErrorKind::InvalidData, format!("bincode: {e}"))
            })?;

        let len = payload.len() as u32;
        let mut frame = Vec::with_capacity(4 + payload.len());
        frame.extend_from_slice(&len.to_be_bytes());
        frame.extend_from_slice(&payload);

        let mut out = self.out.lock().await;
        let stream = out.get_mut(&peer_id).ok_or_else(|| {
            std::io::Error::new(
                std::io::ErrorKind::NotConnected,
                format!("no outgoing connection for peer_id={peer_id}"),
            )
        })?;

        stream.write_all(&frame).await?;
        Ok(())
    }
}
