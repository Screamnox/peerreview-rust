pub mod config;
pub mod messages;
pub mod node;

pub use config::{PeerConfig, PeerConfigEntry};
pub use messages::PeerReviewMsg;
pub use node::{Node, NodeId};

use std::net::SocketAddr;

#[derive(Debug, Clone)]
pub enum PeerStatus {
    Unknown,
    Connected,
}

#[derive(Debug, Clone)]
pub struct PeerInfo {
    pub id: NodeId,
    pub address: SocketAddr,
    pub status: PeerStatus,
    pub public_key_b64: String,
}
